# EV Future – Smart Peer-to-Peer Charging & Green Mobility

This is a simple React-based landing page for "EV Future", a concept for an eco-friendly, peer-to-peer EV charging platform. The site highlights the problem, solution, features, target audience, and contact details.

## Quick Start

1. **Clone the Repository** (or copy the files into your project):

   ```bash
   git clone <your-repo-url>
   cd <your-repo-folder>